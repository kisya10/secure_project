<?php
include 'db.php'; // Ensure db.php is included correctly
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if session is not started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve form data
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $password = $_POST['password'];
    $security_question = htmlspecialchars($_POST['security_question']);

    // Validate password
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,}$/', $password)) {
        $error_message = "Password must be at least 8 characters long, contain at least one special character, and include both uppercase and lowercase letters.";
    } else {
        // Check if the email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        if ($stmt === false) {
            $error_message = "Database error. Please try again later.";
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $error_message = "Email is already in use. Please use a different email.";
            } else {
                // Hash the password if it meets the requirements
                $password_hashed = password_hash($password, PASSWORD_DEFAULT);

                // Prepare SQL statement
                $stmt = $conn->prepare("INSERT INTO users (username, email, password, security_question) VALUES (?, ?, ?, ?)");
                if ($stmt === false) {
                    $error_message = "Database error. Please try again later.";
                } else {
                    $stmt->bind_param("ssss", $username, $email, $password_hashed, $security_question);

                    // Execute statement
                    if ($stmt->execute()) {
                        $success_message = "Registration successful!";
                    } else {
                        $error_message = "Registration failed. Please try again.";
                    }

                    // Close statement
                    $stmt->close();
                }
            }
            $stmt->close();
        }
    }
}
?>

<!-- Rest of your HTML code remains unchanged -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .content-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .content-container img {
            max-width: 150px;
            height: auto;
            border-radius: 8px;
        }
        .error-message {
            color: red;
        }
        .success-message {
            color: green;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-container">
            <img src="utm_logo.jpg" alt="UTM Logo" class="header-logo">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profile.php" class="profile-button">Profile</a>
            <?php endif; ?>
        </div>
    </header>
    <div class="content-container">
        <h1>Register</h1>
        <?php if (!empty($success_message)): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="POST" action="register.php" onsubmit="return validatePassword()">
            <input type="text" name="username" placeholder="Username" required><br><br>
            <input type="email" name="email" placeholder="Email" required><br><br>
            <input type="password" name="password" id="password" placeholder="Password" required><br><br>
            <input type="text" name="security_question" placeholder="What is your favorite dish?" required><br><br>
            <button type="submit" style="background-color: #007bff; color: white;">Register</button>
        </form>
    </div>
    
    <script>
        function validatePassword() {
            const password = document.getElementById('password').value;
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,}$/;

            if (!regex.test(password)) {
                alert('Password must be at least 8 characters long, contain at least one special character, and include both uppercase and lowercase letters.');
                return false;
            }
            return true;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/web3@1.6.0/dist/web3.min.js"></script>
    <script>
        async function connectWallet() {
            if (window.ethereum) {
                try {
                    await window.ethereum.request({ method: 'eth_requestAccounts' });
                    const accounts = await web3.eth.getAccounts();
                    document.getElementById('eth_address').value = accounts[0];
                } catch (error) {
                    console.error(error);
                    alert('MetaMask authentication failed: ' + error.message);
                }
            } else {
                alert('MetaMask is not installed');
            }
        }
    </script>
</body>
</html>
