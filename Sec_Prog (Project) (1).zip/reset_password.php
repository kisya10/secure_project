<?php
include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = htmlspecialchars($_POST['token']);
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("SELECT user_id FROM password_reset_requests WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $request = $result->fetch_assoc();
    $stmt->close();

    if ($request) {
        $user_id = $request['user_id'];
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $new_password, $user_id);
        if ($stmt->execute()) {
            echo "Password updated successfully!";
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM password_reset_requests WHERE token = ?");
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Invalid token.";
    }
} elseif (isset($_GET['token'])) {
    $token = htmlspecialchars($_GET['token']);
} else {
    die("No token provided.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="header">
        <div class="header-container">
            <img src="utm_logo.jpg" alt="UTM Logo" class="header-logo">
            <a href="profile.php" class="profile-button">Profile</a>
        </div>
    </header>
    <div class="content-container">
        <h1>Reset Password</h1>
        <form method="POST" action="reset_password.php">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>" required>
            <input type="password" name="new_password" placeholder="New Password" required><br><br>
            <button type="submit">Reset Password</button>
        </form>
    </div>
</body>
</html>
