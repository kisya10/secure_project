<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];
    $security_question = htmlspecialchars($_POST['security_question']); // Add this line

    $stmt = $conn->prepare("SELECT id, username, password, security_question FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($user_id, $db_username, $db_password, $db_security_question);
    $stmt->fetch();
    $stmt->close();

    if (password_verify($password, $db_password) && $security_question === $db_security_question) {
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $db_username;
        header("Location: schedule.php"); // Redirect after successful login
        exit();
    } else {
        $error_message = "Invalid username, password, or security answer.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .content-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-container">
            <img src="utm_logo.jpg" alt="UTM Logo" class="header-logo">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profile.php" class="profile-button">Profile</a>
            <?php endif; ?>
        </div>
    </header>
    <div class="content-container">
        <h1>Login</h1>
        <?php if (isset($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="POST" action="login.php">
            <input type="text" name="username" placeholder="Username" required><br><br>
            <input type="password" name="password" placeholder="Password" required><br><br>
            <input type="text" name="security_question" placeholder="What is your favorite dish?" required><br><br>
            <button type="submit" style="background-color: #007bff; color: white;">Login</button>
        </form>
        <br>
    </div>
</body>
</html>
