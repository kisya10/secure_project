<?php
require 'vendor/autoload.php';
require('fpdf/fpdf.php');
include 'db.php';
session_start();

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_POST['timetable_data'])) {
    exit('No timetable data provided.');
}

$timetable_data = json_decode($_POST['timetable_data'], true);

class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Your Schedule', 0, 1, 'C');
        $this->Ln(10);
    }

    function CreateTable($data) {
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(20, 7, 'Time', 1);
        $this->Cell(30, 7, 'Sunday', 1);
        $this->Cell(30, 7, 'Monday', 1);
        $this->Cell(30, 7, 'Tuesday', 1);
        $this->Cell(30, 7, 'Wednesday', 1);
        $this->Cell(30, 7, 'Thursday', 1);
        $this->Ln();

        $this->SetFont('Arial', '', 10);
        for ($hour = 8; $hour <= 17; $hour++) {
            $this->Cell(20, 6, sprintf("%02d", $hour) . ':00 - ' . sprintf("%02d", $hour + 1) . ':00', 1);
            for ($day_index = 0; $day_index < 5; $day_index++) {
                $content = $data[$hour][$day_index]['subject_code'] . "\n" . $data[$hour][$day_index]['subject'] . "\n" . $data[$hour][$day_index]['location'];
                $this->Cell(30, 6, $content, 1);
            }
            $this->Ln();
        }
    }
}

if (isset($_POST['export_pdf'])) {
    $pdf = new PDF();
    $pdf->AddPage();
    $pdf->CreateTable($timetable_data);
    $pdf->Output('D', 'Schedule.pdf'); // Force download PDF
    exit();
}

if (isset($_POST['export_excel'])) {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set header
    $sheet->setCellValue('A1', 'Time');
    $sheet->setCellValue('B1', 'Sunday');
    $sheet->setCellValue('C1', 'Monday');
    $sheet->setCellValue('D1', 'Tuesday');
    $sheet->setCellValue('E1', 'Wednesday');
    $sheet->setCellValue('F1', 'Thursday');

    // Populate data
    $row = 2;
    for ($hour = 8; $hour <= 17; $hour++) {
        $sheet->setCellValue('A' . $row, sprintf("%02d", $hour) . ':00 - ' . sprintf("%02d", $hour + 1) . ':00');
        for ($day_index = 0; $day_index < 5; $day_index++) {
            $content = $timetable_data[$hour][$day_index]['subject_code'] . "\n" . $timetable_data[$hour][$day_index]['subject'] . "\n" . $timetable_data[$hour][$day_index]['location'];
            $sheet->setCellValueByColumnAndRow($day_index + 1, $row, $content);
        }
        $row++;
    }

    // Save Excel file and force download
    $filename = 'Schedule.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit();
}
?>
