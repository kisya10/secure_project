<!-- C:/xampp/htdocs/timetable/test.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Test Page</title>
</head>
<body>
    <h1>Apache is working!</h1>
</body>
</html>
