<?php
require('fpdf/fpdf.php');
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize timetable data array
$timetable_data = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['timetable'])) {
        $timetable_data = $_POST['timetable'];
    } else {
        echo "No timetable data provided.<br>";
        exit();
    }

    // Check if the form was submitted for updating the schedule or exporting to PDF
    if (isset($_POST['export_pdf'])) {
        class PDF extends FPDF {
            function CreateTable($data) {
                $this->SetFont('Arial', 'B', 12);
                $this->Cell(25, 10, 'Time', 1);
                $this->Cell(42, 10, 'Sunday', 1);
                $this->Cell(42, 10, 'Monday', 1);
                $this->Cell(42, 10, 'Tuesday', 1);
                $this->Cell(42, 10, 'Wednesday', 1);
                $this->Cell(42, 10, 'Thursday', 1);
                $this->Ln();
                
               
                
                $this->SetFont('Arial', '', 10);
                for ($hour = 8; $hour <= 17; $hour++) {
                    $this->Cell(25, 8, sprintf("%02d", $hour) . ':00 - ' . sprintf("%02d", $hour + 1) . ':00', 1);
                    for ($day_index = 0; $day_index < 5; $day_index++) {
                        $subject_code = isset($data[$hour][$day_index]['subject_code']) ? $data[$hour][$day_index]['subject_code'] : '';
                        $subject = isset($data[$hour][$day_index]['subject']) ? $data[$hour][$day_index]['subject'] : '';
                        $location = isset($data[$hour][$day_index]['location']) ? $data[$hour][$day_index]['location'] : '';
                        $content = $subject_code . "\n" . $subject . "\n" . $location;
                        $this->Cell(42, 8, $content, 1);
                    }
                    $this->Ln();
                }
            }
        }

        // Create PDF instance
        $pdf = new PDF('L', 'mm', 'A4'); // Landscape, millimeters, A4 size
        $pdf->AddPage();
        $pdf->CreateTable($timetable_data);

        // Output PDF as a download
        $pdf->Output('D', 'Timetable.pdf');
        exit();
    } else {
        // Update schedule logic here if needed
        // For now, just print the data for debugging
        echo "<pre>";
        print_r($timetable_data);
        echo "</pre>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Your Schedule</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        input[type="text"] {
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
<header class="header">
    <div class="header-container">
        <img src="utm_logo.jpg" alt="UTM Logo" class="header-logo">
        <a href="profile.php" class="profile-button">Profile</a>
        <a href="logout.php" class="logout-button">Logout</a>
    </div>
</header>
<div class="container">
    <h1>Manage Your Schedule</h1>
    <form method="POST" action="schedule.php">
        <table>
            <thead>
            <tr>
                <th>Time</th>
                <th>Sunday</th>
                <th>Monday</th>
                <th>Tuesday</th>
                <th>Wednesday</th>
                <th>Thursday</th>
            </tr>
            </thead>
            <tbody>
            <?php
            // Generate timetable rows
            for ($hour = 8; $hour <= 17; $hour++) {
                echo '<tr>';
                echo '<td>' . sprintf("%02d", $hour) . ':00 - ' . sprintf("%02d", $hour + 1) . ':00</td>';
                for ($day_index = 0; $day_index < 5; $day_index++) {
                    $subject_code = isset($timetable_data[$hour][$day_index]['subject_code']) ? htmlspecialchars($timetable_data[$hour][$day_index]['subject_code']) : '';
                    $subject = isset($timetable_data[$hour][$day_index]['subject']) ? htmlspecialchars($timetable_data[$hour][$day_index]['subject']) : '';
                    $location = isset($timetable_data[$hour][$day_index]['location']) ? htmlspecialchars($timetable_data[$hour][$day_index]['location']) : '';
                    echo '<td>';
                    echo '<input type="text" name="timetable[' . $hour . '][' . $day_index . '][subject_code]" placeholder="Subject Code" value="' . $subject_code . '"><br>';
                    echo '<input type="text" name="timetable[' . $hour . '][' . $day_index . '][subject]" placeholder="Subject" value="' . $subject . '"><br>';
                    echo '<input type="text" name="timetable[' . $hour . '][' . $day_index . '][location]" placeholder="Location" value="' . $location . '">';
                    echo '</td>';
                }
                echo '</tr>';
            }
            ?>
            </tbody>
        </table>
        
        <button type="submit" name="export_pdf">Export to PDF</button>
    </form>
</div>

<script>
    // Set a timeout to automatically logout after 10 seconds of inactivity
    let logoutTimer;

    function resetLogoutTimer() {
        clearTimeout(logoutTimer);
        logoutTimer = setTimeout(() => {
            alert('You have been logged out due to inactivity.');
            window.location.href = 'logout.php';
        }, 10000); // 10 seconds
    }

    // Reset the timer on any user interaction
    window.onload = resetLogoutTimer;
    document.onmousemove = resetLogoutTimer;
    document.onkeypress = resetLogoutTimer;
    document.onclick = resetLogoutTimer;
    document.onscroll = resetLogoutTimer;
</script>

</body>
</html>


