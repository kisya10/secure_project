CREATE DATABASE IF NOT EXISTS timetable;

USE timetable;

-- Table structure for table `users`
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `eth_address` VARCHAR(42) NOT NULL,
    UNIQUE (`username`),
    UNIQUE (`email`),
    UNIQUE (`eth_address`)
);

-- Table structure for table `schedules`
CREATE TABLE IF NOT EXISTS `schedules` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `course_code` VARCHAR(50) NOT NULL,
    `year` VARCHAR(10) NOT NULL,
    `session` VARCHAR(50) NOT NULL,
    `class_name` VARCHAR(100) NOT NULL,
    `class_time` VARCHAR(50) NOT NULL,
    `day` ENUM('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday') NOT NULL,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
);

CREATE TABLE IF NOT EXISTS `password_reset_requests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `token` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
);
