<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect to schedule.php if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: schedule.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to UTM Timetable Generator</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="header">
        <div class="header-container">
            <img src="utm_logo.jpg" alt="UTM Logo" class="header-logo">
            <?php
            // Check if user is logged in to display profile link
            if (isset($_SESSION['user_id'])) {
                echo '<a href="profile.php" class="profile-button">Profile</a>';
            }
            ?>
        </div>
    </header>
    <div class="container">
        <h1>Welcome to the UTM Timetable Generator</h1>
        <nav>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
            <a href="schedule.php">Schedule</a>
            <a href="how_to_register.php">How to Register</a>
        </nav>
    </div>
    <footer class="footer">
        &copy; 2024 UTM Timetable Generator. All rights reserved.
    </footer>
</body>
</html>
