<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How to Register</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Additional styles specific to this page */
        .content-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .content-container img {
            max-width: 150px; /* Adjust logo size */
            height: auto;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-container">
            <img src="utm_logo.jpg" alt="UTM Logo" class="header-logo">
        </div>
    </header>
    <div class="content-container">
        <h1>How to Register Using MetaMask</h1>
        <ol>
            <li>Download MetaMask from <a href="https://metamask.io/" target="_blank">https://metamask.io/</a> and install it for your browser.</li>
            <li>Set up MetaMask by creating a wallet and securely storing your seed phrase.</li>
            <li>Copy your Ethereum address from MetaMask.</li>
            <li>Proceed to the <a href="register.php">registration page</a> and enter your username, email, password, and Ethereum address.</li>
        </ol>
    </div>
</body>
</html>
