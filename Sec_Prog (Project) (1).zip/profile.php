<?php
session_start();
include 'db.php';

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_email = htmlspecialchars($_POST['email']);
    $security_answer = htmlspecialchars($_POST['security_answer']);

    // Fetch the security answer from the database
    $stmt = $conn->prepare("SELECT security_question FROM users WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("i", $user_id);
    if (!$stmt->execute()) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    }
    $stmt->bind_result($db_security_answer);
    if (!$stmt->fetch()) {
        die('Fetch failed: ' . htmlspecialchars($stmt->error));
    }
    $stmt->close();

    // Check if the provided security answer matches the one in the database
    if ($security_answer === $db_security_answer) {
        // Update the email if the security answer is correct
        $stmt = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
        if ($stmt === false) {
            die('Prepare failed: ' . htmlspecialchars($conn->error));
        }
        $stmt->bind_param("si", $new_email, $user_id);
        if (!$stmt->execute()) {
            die('Execute failed: ' . htmlspecialchars($stmt->error));
        }
        $stmt->close();
        echo "Email updated successfully!";
    } else {
        echo "Error: Incorrect security answer.";
    }
}

// Fetch user data from the database
$stmt = $conn->prepare("SELECT username, email, security_question FROM users WHERE id = ?");
if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}
$stmt->bind_param("i", $user_id);
if (!$stmt->execute()) {
    die('Execute failed: ' . htmlspecialchars($stmt->error));
}
$stmt->bind_result($username, $email, $security_answer);
if (!$stmt->fetch()) {
    die('Fetch failed: ' . htmlspecialchars($stmt->error));
}
$stmt->close();

// Debugging: Check if data is fetched
if (empty($username) || empty($email)) {
    die('No user data found.');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <div class="header-container">
            <img src="utm_logo.jpg" alt="UTM Logo">
        </div>
    </div>
    <div class="content-container">
        <h1>Your Profile</h1>
        <form method="POST" action="profile.php">
            <label>Username: </label><input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" disabled><br><br>
            <label>Email: </label><input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required><br><br>
            <label>What is your favorite dish?</label><input type="text" name="security_answer" value="<?php echo htmlspecialchars($security_answer); ?>" required><br><br>
            <button type="submit">Update Email</button>
        </form>
        <br>
        <a href="schedule.php" class="btn-link">Back to Schedule</a>
    </div>
</body>
</html>
