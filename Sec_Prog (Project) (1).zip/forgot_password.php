<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars($_POST['username']);
    $eth_address = htmlspecialchars($_POST['eth_address']);

    $stmt = $conn->prepare("SELECT id, email FROM users WHERE username = ? AND eth_address = ?");
    $stmt->bind_param("ss", $username, $eth_address);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user) {
        $token = bin2hex(random_bytes(50));
        $stmt = $conn->prepare("INSERT INTO password_reset_requests (user_id, token) VALUES (?, ?)");
        $stmt->bind_param("is", $user['id'], $token);
        $stmt->execute();
        $stmt->close();

        $to = $user['email'];
        $subject = 'Password Reset Request';
        $message = "Click the link below to reset your password:\n\n";
        $message .= "http://example.com/reset_password.php?token=" . $token;
        $headers = 'From: your_email@example.com';

        mail($to, $subject, $message, $headers);

        echo "An email has been sent to your registered email address with instructions to reset your password.";
    } else {
        echo "Invalid credentials. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="header">
        <div class="header-container">
            <img src="utm_logo.jpg" alt="UTM Logo" class="header-logo">
            <a href="profile.php" class="profile-button">Profile</a>
        </div>
    </header>
    <div class="content-container">
        <h1>Forgot Password</h1>
        <form method="POST" action="forgot_password.php">
            <input type="text" name="username" placeholder="Username" required><br><br>
            <input type="text" name="eth_address" placeholder="Ethereum Address" required><br><br>
            <button type="submit">Reset Password</button>
        </form>
    </div>
</body>
</html>
