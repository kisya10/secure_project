<?php
$servername = "localhost"; // usually 'localhost' for Hostinger
$username = "u913916363_kisya01";
$password = "Kisyaxx_12";
$dbname = "u913916363_timetable";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


session_start();

// Define the timeout duration in seconds (10 seconds)

session_start();

// Define the timeout duration in seconds (15 minutes)
define('SESSION_TIMEOUT', 900);

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > SESSION_TIMEOUT)) {
    // Last activity was more than 15 minutes ago
    session_unset();     // Unset $_SESSION variable for the run-time
    session_destroy();   // Destroy the session data in storage
    header("Location: index.php?timeout=true"); // Redirect to index page with timeout flag
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time(); // Update last activity time stamp




?>

